# Fast DataGrid control for WPF
* designed for lasrge data sets
* both columns and rows are defined in model
* uses MVVM design pattern, but (for performance reasons) does not use classic WPF binding
* works only with data virtualization (UI virtualization is not needed as in other WPF datagrid controls)