﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using MVVM_ICommand.Command;

namespace MVVM_ICommand.ViewModel
{
    public class ViewModel
    {

        public ICommand MyCommand { get; set; }

        private string _name;

        public string Name
        {
            get { return _name; }
            set { _name = value; }
        }

        public ViewModel()
        {
            MyCommand = new RelayCommand(ExecuteMyMethod, CanExecuteMyMethod);
        }


        private bool CanExecuteMyMethod(object parameter)
        {
            if (string.IsNullOrEmpty(Name))
            {
                return false;
            }
            else
            {
                if (Name!="")
	            {
		            return true;
	            }
                else
                {
                    return false;
                }
            }
        }

        private void ExecuteMyMethod(object parameter)
        {
            MessageBox.Show("Hello...  " +Name);
        }
        
    }
}
